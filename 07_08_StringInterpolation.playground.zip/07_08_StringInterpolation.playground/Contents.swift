import UIKit

let size = 10
let price = 14.159265358

extension String.StringInterpolation{
    mutating func appendInterpolation(currency value:Double){
        let symbol = Locale.current.currencySymbol ?? " "
        
        let currency = String(format:"%.2f",value)
        appendLiteral(symbol + currency)
    }
    mutating func appendInterpolation(pizzaSize value:Int, isShort:Bool = true){
        var unit = "\u{301e}"
        if !isShort {unit = " inch "}
        let string = String(format:"%i",value)
        appendLiteral(string + unit)
    }
}



var str = "I'd Love a \(pizzaSize:size, isShort:false) Margherita Pizza for \(currency:price) today"
print(str)

